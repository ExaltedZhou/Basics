package SortTimer3;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class SortTimer3 {
	public static void selectionSort(int[] nums) {
		int n = nums.length;
        int min, index, temp;
        for (int j = 0; j < n-1; j++)
        {   
            min = nums[j];
            index = j;
            for(int k = j+1; k < n; k++)
                if(nums[k] < min)
                {   
                    min = nums[k]; 
                    index = k;
                }
            if(index != j)
            {
                temp = nums[j];
                nums[j] = nums[index];
                nums[index] = temp;
            }
        }
	}
	public static void selectionSortPrint(int[] nums) {
		System.out.println("Selection Sort:\nnums = " + Arrays.toString(nums));
		int n = nums.length;
        int min, index, temp;
        for (int j = 0; j < n-1; j++) {   
            min = nums[j];
            index = j;
            for(int k = j+1; k < n; k++)
                if(nums[k] < min)
                {   
                    min = nums[k]; 
                    index = k;
                }
            if(index != j)
            {
                temp = nums[j];
                nums[j] = nums[index];
                nums[index] = temp;
            }
            System.out.println("nums = " + Arrays.toString(nums));
        } 
	}
	public static void insertionSort(int[] nums) {
		int n = nums.length;
		int j,k,next;
		for(j = 1; j < n; j++) {
			next = nums[j];
			for(k = j-1; k >= 0; k--)
				if(next >+ nums[k]) {
					nums[k+1] = next;
					break;
				}
				else 
					nums[k+1] = nums[k];
			if(k < 0)
				nums[0] = next;
		}
	}
	public static void insertionSortPrint(int[] nums) {
		System.out.println("\nInsertion Sort:\nnums = " + Arrays.toString(nums));
		int n = nums.length;
			int j,k,next;
			for(j = 1; j < n; j++) {
				next = nums[j];
				for(k = j-1; k >= 0; k--)
					if(next >+ nums[k]) {
						nums[k+1] = next;
						break;
					}
					else 
						nums[k+1] = nums[k];
				if(k < 0)
					nums[0] = next;
				System.out.println("nums = " + Arrays.toString(nums));
			}
	}
	public static void mergeSort(int[] nums, int left, int right) {
		if(left < right) {
			int middle = (left + right)/2;
			if(left < middle) {
				mergeSort(nums, left, middle); 
			}
			if(middle+1 < right) {
				mergeSort(nums, middle+1, right);
			}
			int m = left; int n = middle+1; int k = 0;
			int result[] = new int[right-left+1];
			while ((m <= middle) && (n <= right)) {
				if(nums[m] <= nums[n]) { 
					result[k] = nums[m];
					m++;
				}
				else {
					result[k] = nums[n];
					n++;
				}
				k++;
				if(n >= middle+1) {
					if(m <= middle) {
						System.arraycopy(nums,m,result,k,middle-m+1);
						m++;k++;
					}
					else {
						System.arraycopy(nums, n, result, k, right-n+1);
						n++;k++;
					}
				}
				nums = Arrays.copyOf(result, result.length);
			}
		}
	}
	public static void mergeSortPrint(int[] nums, int left, int right) {
		if(left < right) {
			int middle = (left + right)/2;
			if(left < middle) {
				mergeSort(nums, left, middle); 
			}
			if(middle+1 < right) {
				mergeSort(nums, middle+1, right);
			}
			int m = left; int n = middle+1; int k = 0;
			int result[] = new int[right-left+1];
			while ((m <= middle) && (n <= right)) {
				if(nums[m] <= nums[n]) { 
					result[k] = nums[m];
					m++;
				}
				else {
					result[k] = nums[n];
					n++;
				}
				k++;
				if(n >= middle+1) {
					if(m <= middle) {
						System.arraycopy(nums, m, result, k, middle-m+1);
						m++;k++;
					}
					else {
						System.arraycopy(nums, n, result, k, right-n+1);
						n++;k++;
					}
				}
				nums = Arrays.copyOf(result, result.length);
				System.out.println("\nnums = " + Arrays.toString(nums));
			}
		}
	}
	public static void quickSort(int[] nums, int left, int right) {
		if(left < right) {
			int p = partition(nums, left, right);
			if(left < p) {
				quickSort(nums, left, p);
			}
			if(p+1 < right) {
				quickSort(nums, p+1, right);
			}
		}
	}
	public static int partition(int[] nums, int left, int right) {
		int pivot = nums[left];
		int i = left-1; int j = right+1;
		while(i < j) {
			for (i++; nums[i] < pivot; i++);
			for (j--; nums[j] > pivot; j--);
			if(i < j) {
				int k = nums[i];
				nums[i] = nums[j];
				nums[j] = k;
			}
		}
		System.out.println("nums = " + Arrays.toString(nums));
		return j; 
	}
	public static void quickSortPrint(int[] nums, int left, int right) {
		if(left < right) {
			System.out.println("\nQuick Sort:\nnums = " + Arrays.toString(nums));
			int p = partition(nums, left, right);
			if(left < p)
				quickSort(nums, left, p);
			if(p+1 < right)
				quickSort(nums, p+1, right);
		}
	}
	public static void main(String[] args) {
		int[] numsSelection = {5,6,4,7,2,1,8,3};
		selectionSortPrint(numsSelection);
		int[] numsInsertion = {5,8,4,6,2,1,7,3};
		insertionSortPrint(numsInsertion);
		int[] numsMerge = {5,3,6,4,2,0,1};
		mergeSortPrint(numsMerge, 0, numsMerge.length-1);
		int[] numsQuick = {5,8,4,7,2,1,6,3};
		quickSortPrint(numsQuick, 0, numsQuick.length-1);
	}
}

	 
